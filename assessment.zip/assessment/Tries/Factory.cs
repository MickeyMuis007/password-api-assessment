namespace Tries {
  public class Factory {
    public static NodeBuilder GetNodeBuilder() {
      return new NodeBuilder();
    }
  }
}